"""Blind selection among three incoming attention messages. Run with Python and NumPy."""
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'tracer_v37'))
import experiment as model

OUT = ROOT / 'results'
FRESH = (108, 109, 110, 111)
METHODS = ('trace', 'message', 'activation', 'shuffled_history', 'norm', 'attention', 'linearized')


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False))


def train(seed, folder):
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(model.DATA))
    p = model.init(rng)
    twin = {k: v.copy() for k, v in p.items()}
    states = [{k: (np.zeros_like(v), np.zeros_like(v)) for k,v in p.items()} for _ in range(2)]
    for step in range(model.STEPS):
        ids = rng.choice(order[:48], model.BATCH, replace=False)
        r = {}
        m, c = model.forward(p, model.DATA[ids], r)
        mt, ct = model.forward(twin, model.DATA[ids])
        assert np.array_equal(m, mt)
        g = model.backward(p, c, m, model.LABEL[ids])
        gt = model.backward(twin, ct, mt, model.LABEL[ids])
        assert all(np.array_equal(g[k], gt[k]) for k in p)
        model.save(folder, f'train_{step:03}.npz', p, r, ids)
        model.update(p, g, states[0], step+1)
        model.update(twin, gt, states[1], step+1)
        assert all(np.array_equal(p[k], twin[k]) for k in p)
    r = {}
    ids = order[48:]
    m, _ = model.forward(p, model.DATA[ids], r)
    assert np.array_equal(m, model.forward(twin, model.DATA[ids])[0])
    model.save(folder, 'inference.npz', p, r, ids)


def cut_effects(p, r):
    margin, _ = model.forward(p, r['tokens'])
    assert np.array_equal(margin, r['margin'])
    return np.stack([model.forward(p, r['tokens'], cut=j)[0]-margin for j in model.SOURCES], axis=1)


def cards(p, r):
    # Arrays are occurrence x candidate x features. Receiver state is shared across siblings.
    msg = r['msg'][:, 3, :3]
    pre = np.broadcast_to(r['pre'][:, 3, None], (*msg.shape[:2], model.H))
    y = np.broadcast_to(r['y'][:, 3, None], msg.shape)
    activation = np.concatenate([r['x'][:, :3], y, np.tanh(pre)], axis=-1)
    return dict(weight=r['w'][:,3,:3,None], message=msg, projected=msg @ p['U'],
                receiver=pre, activation=activation)


def choose(card, history, effect, shuffled_effect):
    # No addresses, tokens, model predictions, or intervention data from the query.
    distances = {k: model.distance(history[k], card[k]) for k in history}
    route = sum(distances[k] for k in ('weight','message','projected','receiver'))
    nearest = {k:int(np.argmin(d)) for k,d in dict(trace=route, message=distances['message'],
                                                   activation=distances['activation']).items()}
    scores = {k:float(effect[idx]) for k,idx in nearest.items()}
    scores['shuffled_history'] = float(shuffled_effect[nearest['trace']])
    scores['norm'] = float(np.linalg.norm(card['message']))
    scores['attention'] = float(card['weight'][0])
    return scores, nearest


def run(seed):
    folder = OUT/f'seed_{seed}'
    folder.mkdir(parents=True, exist_ok=True)
    if seed in FRESH:
        snapshots = folder/'snapshots'
        snapshots.mkdir(exist_ok=True)
        train(seed, snapshots)
    else:
        snapshots = model.OUT/f'seed_{seed}'
    rng = np.random.default_rng(38000+seed)
    effects, batches = [], []
    for step in range(model.STEPS):
        p,r = model.load(snapshots,f'train_{step:03}.npz')
        effects.append(cut_effects(p,r))
        batches.append(cards(p,r))
    ef = np.concatenate(effects)
    shuffled = np.take_along_axis(ef,rng.random(ef.shape).argsort(axis=1),axis=1)
    order = rng.permutation(ef.size)
    history = {k:np.concatenate([b[k] for b in batches]).reshape(ef.size,-1)[order] for k in batches[0]}
    effect, shuffled = ef.ravel()[order], shuffled.ravel()[order]
    p, r = model.load(snapshots,'inference.npz')
    heldout = cards(p,r)
    plans, keys = [], []
    for i in range(len(r['margin'])):
        key = rng.permutation(3)
        keys.append(key)
        entries = []
        for j in key:
            card = {k:a[i,j] for k,a in heldout.items()}
            scores, ids = choose(card, history, effect, shuffled)
            # No-history local derivative at the unmodified operating point.
            slope = (1-np.tanh(card['receiver'])**2) * (p['T'] @ p['head'])
            scores['linearized'] = float(-card['message'] @ p['head'] - card['projected'] @ slope)
            entries.append(dict(scores=scores, historical_ids={k:int(order[v]) for k,v in ids.items()}))
        plans.append(dict(query=i,cards=entries,picks={k:int(np.argmax([abs(e['scores'][k]) for e in entries])) for k in METHODS}))
    dump(folder/'predictions.json', plans)
    # Score only after every choice is written. Compare recorded winner with all three interventions.
    actual = cut_effects(p,r)
    results = []
    for plan,key,delta in zip(plans,keys,actual):
        mags = abs(delta[key])
        assert np.sum(mags==mags.max())==1
        winner = int(mags.argmax())
        results.append(dict(query=plan['query'], anonymous_to_source=key.tolist(),delta=delta[key].tolist(),
                            winner=winner,gap=float(mags.max()-np.sort(mags)[-2]),
                            correct={k:v==winner for k,v in plan['picks'].items()}))
    dump(folder/'validation.json',results)
    return dict(seed=seed, inputs=len(results),correct={k:sum(a['correct'][k] for a in results) for k in METHODS},
                model_correct=int(np.sum((r['margin']>=0)==model.LABEL[r['example_ids']])),
                trace_message_disagreements=sum(a['picks']['trace']!=a['picks']['message'] for a in plans),
                min_gap=min(a['gap'] for a in results))


if __name__=='__main__':
    reports = [run(s) for s in (*model.SEEDS,*FRESH)]
    dump(OUT/'summary.json',reports)
    for label, rows in [('v37',reports[:4]), ('fresh',reports[4:])]:
        print(label,{k:sum(r['correct'][k] for r in rows) for k in METHODS})

"""Predict the effect of removing one incoming message, before intervening on a held-out input."""
import json
import sys
from pathlib import Path
from graphlib import TopologicalSorter

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/'tracer_v38'))
from hidden_branch import model, train, cut_effects

OUT = HERE/'results'
FRESH = tuple(range(112,120))
ARCHIVE = tuple(range(108,112))
SCHEMA = json.loads((HERE.parent/'tracer_v37/results/graph.json').read_text())
METHODS = ('merge', 'history', 'message_and_merge', 'earlier_only', 'token_and_merge')


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False))


def branch(root):
    parents = {}
    def visit(k):
        if k in parents:
            return
        parents[k] = [p for p in SCHEMA[k]['parents'] if p in SCHEMA]
        for p in parents[k]:
            visit(p)
    visit(root)
    return {k:parents[k] for k in TopologicalSorter(parents).static_order()}


def values(record, keys):
    out = {}
    for k in keys:
        n = SCHEMA[k]
        v = record[n['field']][(slice(None),*n['index'])]
        out[k] = v.reshape(v.shape[0],-1)
    return out


def distances(k, bank, query):
    if k.startswith('tokens/'):
        return (bank[:,0]!=query[0]).astype(float)
    denom = np.linalg.norm(bank,axis=1)+np.linalg.norm(query)
    return np.linalg.norm(bank-query,axis=1)/np.maximum(denom,1e-12)


def history_distance(graph, local):
    running, by_field = {}, {}
    for k, parents in graph.items():
        score = local[k]
        if parents:
            score = (score+np.mean([running[p] for p in parents],axis=0))/2
        running[k] = score
        by_field.setdefault(SCHEMA[k]['field'],[]).append(score)
    return np.mean([np.mean(v,axis=0) for v in by_field.values()],axis=0)


def run(seed):
    folder = OUT/f'seed_{seed}'
    folder.mkdir(parents=True,exist_ok=True)
    if seed in FRESH:
        snaps = folder/'snapshots'
        snaps.mkdir(exist_ok=True)
        train(seed,snaps)
    else:
        snaps = HERE.parent/f'tracer_v38/results/seed_{seed}/snapshots'
    pf, query = model.load(snaps,'inference.npz')
    roots = [f'msg/3/{s}' for s in model.SOURCES]
    graphs = [branch(k) for k in roots]
    keys = sorted(set.union(*(set(g) for g in graphs),{'y/3'}))
    batches, effects = [], []
    for step in range(model.STEPS):
        p,r = model.load(snaps,f'train_{step:03}.npz')
        assert not np.intersect1d(r['example_ids'],query['example_ids']).size
        batches.append(values(r,keys))
        effects.append(cut_effects(p,r))
    bank = {k:np.concatenate([b[k] for b in batches]) for k in keys}
    history_effect = np.concatenate(effects)
    q = values(query,keys)
    predictions = []
    for i,example in enumerate(query['example_ids']):
        local = {k:distances(k,bank[k],q[k][i]) for k in keys}
        merge = local['y/3']
        for s,graph in enumerate(graphs):
            msg = local[roots[s]]
            earlier = {k:v for k,v in graph.items() if k!=roots[s]}
            scores = dict(merge=merge,history=(merge+history_distance(graph,local))/2,
                          message_and_merge=(merge+msg)/2,
                          earlier_only=(merge+history_distance(earlier,local))/2,
                          token_and_merge=(merge+local[f'tokens/{s}'])/2)
            idx = {m:int(scores[m].argmin()) for m in METHODS}
            predictions.append(dict(seed=seed,example=int(example),query=i,source=s,
                tokens=query['tokens'][i].tolist(), nearest_merge_distance=float(merge.min()),
                indices=idx, predicted={m:float(history_effect[j,s]) for m,j in idx.items()}))
    dump(folder/'predictions.json',predictions)
    actual = cut_effects(pf,query)
    rows = []
    for pred in predictions:
        i,s = pred['query'],pred['source']
        delta = float(actual[i,s])
        rows.append(dict(**pred,actual=delta,original=float(query['margin'][i]),
                         error={m:abs(pred['predicted'][m]-delta) for m in METHODS}))
    dump(folder/'validation.json',rows)
    return rows


def stats(rows):
    return dict(cuts=len(rows), mae={m:float(np.mean([r['error'][m] for r in rows])) for m in METHODS},
                distinct_inputs=len({r['example'] for r in rows}),
                sign_hits={m:sum(int(np.sign(r['predicted'][m])==np.sign(r['actual'])) for r in rows) for m in METHODS})


if __name__=='__main__':
    all_rows = {s:run(s) for s in (*ARCHIVE,*FRESH)}
    report = {'seeds':{s:stats(r) for s,r in all_rows.items()}}
    for name,seeds in [('archive',ARCHIVE),('fresh',FRESH)]:
        rows = [r for s in seeds for r in all_rows[s]]
        report[name] = stats(rows)
        close = [r for r in rows if r['nearest_merge_distance']<=0.15]
        report[name+'_close'] = stats(close) if close else None
    dump(OUT/'summary.json',report)
    print(json.dumps(report['fresh'],indent=2))

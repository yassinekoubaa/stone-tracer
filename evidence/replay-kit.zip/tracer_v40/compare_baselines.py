"""Retrospective paired comparison on the existing v40 held-out cuts."""
import json
import numpy as np
from branch_changes import FRESH, OUT, distances, dump, model, cut_effects
from hidden_branch import cards


def metrics(pred, actual, signed=True):
    hits = (np.abs(pred).argmax(axis=1)==np.abs(actual).argmax(axis=1)).sum()
    return dict(top1=int(hits), mae=float(np.mean(abs(pred-actual))) if signed else None)


def compare(seed):
    folder = OUT/f'seed_{seed}'
    snaps = folder/'snapshots'
    effects, activations = [], []
    for step in range(model.STEPS):
        p,r = model.load(snaps,f'train_{step:03}.npz')
        effects.append(cut_effects(p,r))
        activations.append(cards(p,r)['activation'])
    effects, activations = np.concatenate(effects), np.concatenate(activations)
    p,q = model.load(snaps,'inference.npz')
    c = cards(p,q)
    actual = cut_effects(p,q)
    locked = json.loads((folder/'predictions.json').read_text())
    predictions = {k:np.zeros_like(actual) for k in ('merge','history','message_and_merge','activation')}
    idx = np.zeros(actual.shape,dtype=int)
    for row in locked:
        i,s = row['query'],row['source']
        idx[i,s] = row['indices']['history']
        for key in ('merge','history','message_and_merge'):
            predictions[key][i,s] = row['predicted'][key]
        assert predictions['history'][i,s]==effects[idx[i,s],s]
        j = distances('activation',activations[:,s],c['activation'][i,s]).argmin()
        predictions['activation'][i,s] = effects[j,s]
    slope = (1-np.tanh(c['receiver'])**2)*(p['T']@p['head'])
    predictions['sensitivity'] = -c['message']@p['head']-(c['projected']*slope).sum(axis=-1)
    predictions['attention'] = c['weight'][...,0]
    predictions['norm'] = np.linalg.norm(c['message'],axis=-1)
    results = {k:metrics(v,actual,k not in ('norm','attention')) for k,v in predictions.items()}
    rng = np.random.default_rng(40100+seed)
    shuffles = []
    for _ in range(100):
        shuffled = np.take_along_axis(effects,rng.random(effects.shape).argsort(axis=1),axis=1)
        shuffles.append(metrics(shuffled[idx,np.arange(3)],actual))
    results['shuffled'] = {k:float(np.mean([r[k] for r in shuffles])) for k in shuffles[0]}
    return results


if __name__=='__main__':
    seeds = {s:compare(s) for s in FRESH}
    agg = {}
    for method in seeds[FRESH[0]]:
        rows = [r[method] for r in seeds.values()]
        agg[method] = dict(top1=sum(r['top1'] for r in rows),
                           mae=np.mean([r['mae'] for r in rows]) if rows[0]['mae'] is not None else None)
    dump(OUT/'baseline_comparison.json',dict(seeds=seeds,aggregate=agg))
    print(json.dumps(agg,indent=1))

import itertools
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'tracer_v44'))
import journeys as j
m=j.model
OUT=HERE/'results'
REPS=16


def dump(path,data):
    path.write_text(json.dumps(data,indent=2))


def alternatives(batch,removed,target):
    n=len(removed)
    features=[(tuple(x[:3]==target[:3]),int(label)) for x,label in zip(batch['tokens'],m.LABEL[batch['example_ids']])]
    base=Counter(features[a] for a in removed)
    best=None
    pool=[]
    for sub in itertools.combinations(range(m.BATCH),n):
        hist=Counter(features[a] for a in sub)
        rank=(len(set(sub)&set(removed)),sum((base-hist).values()))
        if best is None or rank<best:
            best=rank
            pool=[]
        if rank==best:
            pool.append(sub)
    return pool


def run(seed,plans):
    d=j.archive(seed)
    final,q=m.load(d,'inference.npz')
    checkpoints=[m.load(d,f'train_{i:03}.npz') for i in range(m.STEPS)]
    p={k:v.copy() for k,v in checkpoints[0][0].items()}
    a={k:(np.zeros_like(v),np.zeros_like(v)) for k,v in p.items()}
    moments=[]
    for t,(saved,batch) in enumerate(checkpoints):
        assert all(np.array_equal(v,saved[k]) for k,v in p.items())
        moments.append({k:(v.copy(),w.copy()) for k,(v,w) in a.items()})
        out,c=m.forward(p,batch['tokens'])
        m.update(p,m.backward(p,c,out,m.LABEL[batch['example_ids']]),a,t+1)
    assert all(np.array_equal(v,final[k]) for k,v in p.items())
    def replay(schedule):
        t0=min(schedule)
        p={k:v.copy() for k,v in checkpoints[t0][0].items()}
        a={k:(v.copy(),w.copy()) for k,(v,w) in moments[t0].items()}
        for t in range(t0,m.STEPS):
            batch=checkpoints[t][1]
            logits,c=m.forward(p,batch['tokens'])
            labels=m.LABEL[batch['example_ids']].astype(float)
            if t in schedule:
                ix=list(schedule[t])
                labels[ix]=(1/(1+np.exp(-logits)))[ix]
            m.update(p,m.backward(p,c,logits,labels),a,t+1)
        r={}
        m.forward(p,q['tokens'],r)
        return r
    reports=[]
    for plan in plans:
        i=plan['i']
        target=q['tokens'][i]
        schedule=defaultdict(list)
        for h in sorted(set(plan['record']['donors'].values())):
            schedule[h//8].append(h%8)
        pools={t:alternatives(checkpoints[t][1],ix,target) for t,ix in schedule.items()}
        def audit(sch):
            rr=replay(sch)
            diff=rr['margin']-q['margin']
            stones={}
            for k in j.NAMES:
                node=j.SCHEMA[k]
                slot=(i,*node['index'])
                x=np.atleast_1d(q[node['field']][slot])
                y=np.atleast_1d(rr[node['field']][slot])
                stones[k]=dict(factual=x.tolist(),replay=y.tolist(),
                               distance=float(j.difference(node['field'],y[None],x)[0]))
            return dict(schedule={t:list(v) for t,v in sch.items()},delta=float(diff[i]),
                        flip=bool((q['margin'][i]>=0)!=(rr['margin'][i]>=0)),
                        other_abs=float(np.delete(abs(diff),i).mean()),all_changes=diff.tolist(),stones=stones)
        selected=audit(schedule)
        rng=np.random.default_rng(seed*1000+i)
        controls=[]
        for _ in range(REPS):
            sch={t:options[rng.integers(len(options))] for t,options in pools.items()}
            control=audit(sch)
            controls.append(control)
        reports.append(dict(seed=seed,i=i,input=target.tolist(),answer=int(q['margin'][i]>=0),
                            margin=float(q['margin'][i]),donors=plan['record']['donors'],
                            selected=selected,controls=controls))
    return reports


def main():
    OUT.mkdir(exist_ok=True)
    records=[]
    for seed in range(104,144):
        rows=json.loads((j.OUT/f'seed_{seed}.json').read_text())
        plans=[r for r in rows if r['record']['status']=='combination']
        if plans:
            block=run(seed,plans)
            dump(OUT/f'seed_{seed}.json',block)
            records.extend(block)
    sel=np.array([abs(r['selected']['delta']) for r in records])
    off=np.array([r['selected']['other_abs'] for r in records])
    ctr=np.array([[abs(c['delta']) for c in r['controls']] for r in records])
    coff=np.array([[c['other_abs'] for c in r['controls']] for r in records])
    report=dict(cases=len(records),models=len({r['seed'] for r in records}),selected_mean=float(sel.mean()),
                control_mean=float(ctr.mean()),selected_median=float(np.median(sel)),
                larger=int(sum(sel>ctr.mean(1))),selected_flips=sum(r['selected']['flip'] for r in records),
                control_flips=sum(c['flip'] for r in records for c in r['controls']),control_trials=int(ctr.size),
                selected_other_input_mean=float(off.mean()),control_other_input_mean=float(coff.mean()),
                specificity_advantage=float(((sel-off)-(ctr-coff).mean(1)).mean()),
                specificity_wins=int(sum(sel-off>(ctr-coff).mean(1))),
                unique_control_schedules_by_case=[len({json.dumps(c['schedule'],sort_keys=True) for c in r['controls']}) for r in records])
    dump(OUT/'summary.json',report)
    print(report)


if __name__=='__main__':
    main()

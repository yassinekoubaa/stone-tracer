import json
import sys
from collections import defaultdict
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'tracer_v44'))
sys.path.insert(0,str(HERE.parent/'tracer_v40'))
import journeys as j
from branch_changes import branch,history_distance
m=j.model
OUT=HERE/'results'


def edge_gradient(p,c,margin,target,b,s):
    """Gradient carried by one projected value times its scalar softmax weight."""
    tokens,x,q,k,v,w,value,y,act,z=c
    a=w[b,3]
    h=act[b,3]
    dm=(1/(1+np.exp(-margin[b]))-target[b])/len(target)
    dz=dm*p['head']
    dy=dz+((dz@p['T'].T)*(1-h*h))@p['U'].T
    a_grad=dy@value[b,s]
    ds=-a.copy()
    ds[s]+=1
    ds*=a_grad*a[s]/np.sqrt(m.D)
    dq=ds@k[b]
    dk=ds[:,None]*q[b,3]
    do=a[s]*dy
    dv=do@p['O'].T
    dx=dk@p['K'].T
    dx[3]+=dq@p['Q'].T
    dx[s]+=dv@p['V'].T
    de=np.zeros_like(p['emb'])
    np.add.at(de,tokens[b],dx)
    return dict(emb=de,pos=dx,Q=np.outer(x[b,3],dq),K=x[b].T@dk,
                V=np.outer(x[b,s],dv),O=np.outer(v[b,s],do))


def check_gradient(p,tokens,labels):
    rng=np.random.default_rng(46)
    b,s=2,1
    r={}
    margin,c=m.forward(p,tokens,r)
    g=m.backward(p,c,margin,labels)
    for k,v in edge_gradient(p,c,margin,labels,b,s).items():
        g[k]-=v
    direction={k:rng.normal(size=v.shape) for k,v in p.items()}
    def loss(h):
        pp={k:v+h*direction[k] for k,v in p.items()}
        rr={}
        out,_=m.forward(pp,tokens,rr)
        y=rr['y'][b,3]+r['msg'][b,3,s]-rr['msg'][b,3,s]
        out[b]=(y+np.tanh(y@pp['U']+pp['b'])@pp['T']+pp['c'])@pp['head']+pp['bias'][0]
        return m.loss(out,labels)
    err=abs((loss(1e-5)-loss(-1e-5))/2e-5-sum((g[k]*v).sum() for k,v in direction.items()))
    assert err<1e-7
    return float(err)


def run(seed):
    d=j.archive(seed)
    plans=json.loads((j.OUT/f'seed_{seed}.json').read_text())
    final,tests=m.load(d,'inference.npz')
    starts=[m.load(d,f'train_{i:03}.npz') for i in range(m.STEPS)]
    p={k:v.copy() for k,v in starts[0][0].items()}
    state={k:(np.zeros_like(v),np.zeros_like(v)) for k,v in p.items()}
    moments={}
    needed={r['closest']//8 for r in plans}
    for step,(saved,r) in enumerate(starts):
        assert all(np.array_equal(p[k],saved[k]) for k in p)
        if step in needed:
            moments[step]={k:(a.copy(),b.copy()) for k,(a,b) in state.items()}
        margin,c=m.forward(p,r['tokens'])
        labels=m.LABEL[r['example_ids']]
        g=m.backward(p,c,margin,labels)
        m.update(p,g,state,step+1)
    assert all(np.array_equal(p[k],final[k]) for k in p)
    err=check_gradient(starts[0][0],starts[0][1]['tokens'],m.LABEL[starts[0][1]['example_ids']])
    cache={}
    def counter(step,b,src):
        key=(step,b,src)
        if key in cache:
            return cache[key]
        p={k:v.copy() for k,v in starts[step][0].items()}
        state={k:(a.copy(),z.copy()) for k,(a,z) in moments[step].items()}
        for t in range(step,m.STEPS):
            r=starts[t][1]
            labels=m.LABEL[r['example_ids']]
            margin,c=m.forward(p,r['tokens'])
            if t==step and src is None:
                # Make the selected row's logit derivative exactly zero.
                labels=labels.astype(float)
                labels[b]=(1/(1+np.exp(-margin)))[b]
            g=m.backward(p,c,margin,labels)
            if t==step and src is not None:
                for k,v in edge_gradient(p,c,margin,labels,b,src).items():
                    g[k]-=v
            m.update(p,g,state,t+1)
        r={}
        m.forward(p,tests['tokens'],r)
        cache[key]=(p,r)
        return p,r
    obs=[]
    for plan in plans:
        i=plan['i']
        step,b=divmod(plan['closest'],m.BATCH)
        scores=[]
        for s in m.SOURCES:
            graph=branch(f'msg/3/{s}')
            scores.append(float(history_distance(graph,{k:plan['stones'][k]['distance'] for k in graph})))
        src=int(np.argmin(scores))
        fact=float(tests['margin'][i])
        omit=[float(counter(step,t,None)[1]['margin'][i]) for t in range(m.BATCH)]
        stop=[float(counter(step,b,s)[1]['margin'][i]) for s in m.SOURCES]
        pp,rr=counter(step,b,None)
        y=rr['y'][i,3]+tests['msg'][i,3,src]-rr['msg'][i,3,src]
        patch=float((y+np.tanh(y@pp['U']+pp['b'])@pp['T']+pp['c'])@pp['head']+pp['bias'][0])
        obs.append(dict(seed=seed,query=i,input=plan['tokens'],training_step=step,batch_row=b,
                        training_input=starts[step][1]['tokens'][b].tolist(),source=src,
                        factual=fact,omitted=omit,branch_stopped=stop,patched=patch))
    (OUT/f'seed_{seed}.json').write_text(json.dumps(obs,indent=2))
    return obs,err


def report(rows):
    chosen=[];peers=[];edge=[];other=[];flips=[];edge_flips=[];closer=[]
    for r in rows:
        f=r['factual'];b=r['batch_row'];s=r['source']
        od=abs(np.array(r['omitted'])-f)
        ed=abs(np.array(r['branch_stopped'])-f)
        chosen.append(od[b]);peers.append(np.delete(od,b).mean())
        edge.append(ed[s]);other.append(np.delete(ed,s).mean())
        flips.append((f>=0)!=(r['omitted'][b]>=0))
        edge_flips.append((f>=0)!=(r['branch_stopped'][s]>=0))
        closer.append(abs(r['patched']-f)<od[b])
    return dict(cases=len(rows),occurrence_mean=np.mean(chosen),peers_mean=np.mean(peers),
                selected_larger=int(np.sum(np.array(chosen)>peers)),omission_flips=sum(flips),
                occurrence_median=np.median(chosen),branch_mean=np.mean(edge),other_mean=np.mean(other),
                selected_branch_larger=int(np.sum(np.array(edge)>other)),branch_median=np.median(edge),
                branch_flips=sum(edge_flips),patch_closer=int(sum(closer)),
                measurable_occurrences=int(np.sum(np.array(chosen)>1e-8)),measurable_branches=int(np.sum(np.array(edge)>1e-8)))


if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    rows=[];seeds={};errors=[]
    for seed in range(104,112):
        block,err=run(seed)
        rows.extend(block);errors.append(err);seeds[seed]=report(block)
    res=dict(all=report(rows),by_seed=seeds,max_gradient_check_error=max(errors))
    (OUT/'summary.json').write_text(json.dumps(res,indent=2))
    print(res['all'])

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


def render_example(r, target):
    canvas=Image.new('RGB',(1480,620),'#f8f7f1')
    draw=ImageDraw.Draw(canvas)
    def text(x,y,t,size,color='#1b3339',bold=False):
        try:
            font=ImageFont.truetype('Arial Bold.ttf' if bold else 'Arial.ttf',size)
        except OSError:
            font=ImageFont.load_default(size=size)
        draw.text((x,y),t,font=font,fill=color)
    text(40,26,'One inference journey, several historical witnesses',38,bold=True)
    text(42,92,f"Model {r['seed']}  ·  held-out row {r['i']}  ·  input {r['tokens']}  ·  actual answer {r['predicted']}  ·  correct answer {r['expected']}",23)
    stages=[('origin 0','First input fork'),('routing','Attention weights'),
            ('attention merge','Messages merge'),('output merge','Final merge and answer')]
    for i,(name,title) in enumerate(stages):
        w=r['witnesses'][name]
        x=40+i*355
        draw.rounded_rectangle((x,179,x+329,385),radius=16,fill=['#e2ede6','#e1eaf4','#f6e6d7','#e9e3f1'][i])
        text(x+16,201,title,23,bold=True)
        text(x+16,259,'Training input',20)
        text(x+16,292,str(w['tokens']),25,bold=True)
        text(x+16,344,f"Step {w['id']//8}, row {w['id']%8}",19)
    text(42,426,'Four landmarks from the complete overlay',24,bold=True)
    text(42,470,'Each card identifies the training occurrence that matched that part of the inference.',22)
    text(42,511,'The full map follows all 27 connected fragments, including all 12 neuron branches.',22)
    text(42,552,'Different training inputs contributed the matches. No one training occurrence covered the whole journey.',21)
    canvas.save(target)

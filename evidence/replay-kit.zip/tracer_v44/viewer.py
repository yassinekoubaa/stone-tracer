import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def render(rows):
    from journeys import GRAPH, PARTS
    from witnesses import attach
    attach(rows)
    from example_image import render_example
    render_example(next(r for r in rows if r['record']['status']=='combination'), HERE/'example.png')
    data=HERE/'results'
    # Ordinary local scripts also work when the viewer is opened directly from disk.
    for seed in sorted({r['seed'] for r in rows}):
        path=data/f'seed_{seed}.json'
        path.write_text(json.dumps([r for r in rows if r['seed']==seed],separators=(',',':')))
        (data/f'view_{seed}.js').write_text('showSeed('+path.read_text()+');')
    html=r'''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Input-to-answer stone overlays</title>
<style>body{font:16px system-ui;background:#faf9f4;color:#1d303c;margin:2vw auto;max-width:1600px;padding:0 18px}h1{font-size:32px}select{margin:0 12px 0 4px;font:inherit}p{max-width:100ch}.map{overflow:auto;background:white;border:1px solid #ddd}svg{min-width:1250px;width:100%;font:13px monospace}button{font:inherit}td,th{padding:5px 9px;text-align:left;border-bottom:1px solid #ddd}#detail{padding:12px;background:#edece5;overflow-wrap:anywhere}a{color:#215c65}summary{cursor:pointer}label{display:inline-block;margin:6px 0}</style>
<h1>Input-to-answer stone overlays</h1><label>Model <select id="seed"></select></label><label>Inference row <select id="row"></select></label>
<div id="description"></div><h2>Closest intact training journey</h2>
<p>Follow the stones from left to right. Green means the two recorded values align; orange marks a difference. Each line is a recorded parent–child connection. Select a stone to inspect both values. The color is local, so a green stone can have orange ancestors.</p>
<div class="map"><svg id="map" viewBox="0 0 1950 720"></svg></div><p id="detail"></p>
<h2>Historical fragments</h2><p id="why"></p><table><thead><tr><th>Connected fragment</th><th>Training witness</th><th>Stones</th></tr></thead><tbody id="parts"></tbody></table><pre id="witness" style="white-space:pre-wrap"></pre>
<script>
const graph=GRAPH_JSON, parts=PART_JSON, seeds=document.querySelector('#seed'), cases=document.querySelector('#row');
let batch=[], active, script;
for(let s=104;s<144;s++)seeds.add(new Option(s,s));
for(let i=0;i<16;i++)cases.add(new Option(i,i));
function historical(j){return 'step '+Math.floor(j/8)+', row '+(j%8)}
const names=Object.keys(graph), pos={};
['tokens','e','x','q k v','score value','w','msg','y','pre','act','neuron','z','margin'].forEach((fields,c)=>{
 const ks=names.filter(k=>fields.split(' ').includes(k.split('/')[0])).sort((a,b)=>a.localeCompare(b,'en',{numeric:true}));
 ks.forEach((k,i)=>pos[k]=[65+c*150,35+(i+.5)*650/ks.length]);});
function info(k){const v=active.stones[k]; document.querySelector('#detail').textContent=k+'   |   inference: '+v.query.map(n=>n.toFixed(4)).join('  ')+'   |   training: '+v.training.map(n=>n.toFixed(4)).join('  ')+'   |   distance '+v.distance.toFixed(3)+'   |   parents: '+(graph[k].join(', ')||'input');}
function draw(){
 active=batch[Number(cases.value)];const r=active,rec=r.record;
 document.querySelector('#description').innerHTML='<p><b>Inference</b> ['+r.tokens+'] → class '+r.predicted+' (expected '+r.expected+'). <b>Closest training occurrence</b> ['+r.training_tokens+'] → class '+r.training_answer+', '+historical(r.closest)+'.</p><p>'+r.aligned+' of 76 stones align locally. Boundary differences: '+(r.breaks.join(', ')||'none')+'. Locally aligned again immediately after a difference: '+(r.rejoins.join(', ')||'none')+'.</p>';
 let svg='';
 for(const [k,ps] of Object.entries(graph))for(const p of ps){const [x,y]=pos[p],[u,v]=pos[k];svg+='<path d="M '+(x+46)+' '+y+' C '+(x+95)+' '+y+', '+(u-95)+' '+v+', '+(u-46)+' '+v+'" fill="none" stroke="#b6c2bd" stroke-width="1.6"/>';}
 for(const k of names){const [x,y]=pos[k],c=r.stones[k].aligned;svg+='<g tabindex="0" role="button" aria-label="'+k+'" data-k="'+k+'" style="cursor:pointer"><rect x="'+(x-46)+'" y="'+(y-15)+'" width="92" height="30" rx="11" stroke="'+(c?'#13715b':'#b05620')+'" fill="'+(c?'#d9f0e7':'#ffe1c8')+'"/><text x="'+x+'" y="'+(y+5)+'" text-anchor="middle">'+k+'</text></g>';}
 const m=document.querySelector('#map');m.innerHTML=svg;m.querySelectorAll('g').forEach(g=>{g.onclick=()=>info(g.dataset.k);g.onkeydown=e=>{if(e.key==='Enter')info(g.dataset.k)}});info('margin');
 const labels={whole:'One historical occurrence aligns throughout.',combination:'A complete, boundary-compatible combination of historical fragments was found.',partial:'Partial correspondence. At least one required fragment had no qualifying training occurrence.',incompatible:'Every fragment had candidates, but no compatible assembly existed.',unresolved:'Candidate fragments existed; the bounded search was inconclusive.'};
 document.querySelector('#why').textContent=labels[rec.status]+' For a partial result, each listed witness is local. Different rows have not been joined into a verified whole.';
 document.querySelector('#witness').textContent=''; document.querySelector('#parts').innerHTML=Object.entries(parts).map(([k,v])=>{let j=rec.donors?.[k]??rec.fragment_records?.[k]?.closest; return '<tr><th>'+(r.witnesses?'<button data-frag="'+k+'">'+k+'</button>':k)+'</th><td>'+(j===undefined?'No witness':historical(j))+'</td><td>'+v.join(' · ')+'</td></tr>'}).join('');
 document.querySelectorAll('[data-frag]').forEach(b=>b.onclick=()=>{const k=b.dataset.frag,w=r.witnesses[k];
 document.querySelector('#witness').textContent=k+' · '+historical(w.id)+' · training input ['+w.tokens+']\n'+Object.keys(w.values).map(n=>n+'   inference '+r.stones[n].query.map(v=>v.toFixed(3)).join(' ')+'   |   training '+w.values[n].map(v=>v.toFixed(3)).join(' ')).join('\n');
 document.querySelector('#witness').scrollIntoView({block:'nearest'});});
}
function showSeed(b){if(b[0].seed!==Number(seeds.value))return;batch=b;draw()}
function load(){if(script)script.remove();script=document.createElement('script');script.src='results/view_'+seeds.value+'.js';document.body.appendChild(script)}
const url=new URLSearchParams(location.search);seeds.value=url.get('seed')||106;cases.value=url.get('row')||5;seeds.onchange=load;cases.onchange=()=>{if(batch[0]?.seed===Number(seeds.value))draw()};load();
</script>'''
    (HERE/'journeys.html').write_text(html.replace('GRAPH_JSON',json.dumps(GRAPH)).replace('PART_JSON',json.dumps(PARTS)))

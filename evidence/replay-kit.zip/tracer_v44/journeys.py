import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(BASE/'tracer_v39'))
from overlay import ancestors, difference, values
sys.path.insert(0,str(BASE/'tracer_v37'))
import experiment as model

OUT=HERE/'results'
TOL=.15
SCHEMA=json.loads((BASE/'tracer_v37/results/graph.json').read_text())
GRAPH=ancestors(SCHEMA)
NAMES=list(GRAPH)
INDEX={k:i for i,k in enumerate(NAMES)}
FIELDS=[SCHEMA[k]['field'] for k in NAMES]
NUM=np.array([f!='tokens' for f in FIELDS])
PARENTS=[[INDEX[p] for p in ps] for ps in GRAPH.values()]
MARGIN=INDEX['margin']


def archive(seed):
    if seed<108:
        return BASE/f'tracer_v37/results/seed_{seed}'
    version=38 if seed<112 else 40 if seed<120 else 41 if seed<128 else 42 if seed<136 else 43
    return BASE/f'tracer_v{version}/results/seed_{seed}/snapshots'


def fragments():
    parts={}
    for i in range(4):
        parts[f'origin {i}']=[f'{f}/{i}' for f in ['tokens','e','x','k','v','value']]+(['q/3'] if i==3 else [])
        parts[f'score {i}']=['q/3',f'k/{i}',f'score/3/{i}']
        parts[f'message {i}']=[f'value/{i}',f'w/3/{i}',f'msg/3/{i}']
    parts['routing']=[f'{f}/3/{i}' for f in ('score','w') for i in range(4)]
    parts['attention merge']=['x/3',*[f'msg/3/{i}' for i in range(4)],'y/3']
    for h in range(12):
        parts[f'neuron {h}']=['y/3',*[f'{f}/3/{h}' for f in ('pre','act','neuron')]]
    parts['output merge']=['y/3',*[f'neuron/3/{h}' for h in range(12)],'z/3','margin']
    assert set.union(*(set(p) for p in parts.values()))==set(NAMES)
    for child,parents in GRAPH.items():
        assert all(any(child in p and a in p for p in parts.values()) for a in parents)
    return parts


PARTS=fragments()
PART_IDS={k:[INDEX[x] for x in nodes if SCHEMA[x]['field']!='tokens'] for k,nodes in PARTS.items()}
SHARED={(a,b):sorted(set(PARTS[a])&set(PARTS[b])) for a in PARTS for b in PARTS if a!=b}


def ranking_weights():
    eye=np.eye(len(NAMES))
    running=[]
    groups=defaultdict(list)
    for j,k in enumerate(NAMES):
        ps=PARENTS[j]
        v=(eye[j]+np.mean([running[i] for i in ps],axis=0))/2 if ps else eye[j]
        running.append(v)
        if k!='margin':
            groups[FIELDS[j]].append(v)
    return np.mean([np.mean(v,axis=0) for v in groups.values()],axis=0)


WEIGHTS=ranking_weights()


def classify(ds,bank,answer,detail):
    same=(bank['margin'][:,0]>=0)==answer
    whole=np.flatnonzero((ds[NUM].max(0)<=TOL)&same)
    out={'whole_count':len(whole),'literal_count':int(np.sum(ds[:,whole].max(0)<=TOL)) if len(whole) else 0}
    domains={}
    if len(whole):
        j=int(whole[np.argmin(WEIGHTS@ds[:,whole])])
        return dict(**out,status='whole',donors={k:j for k in PARTS})
    missing=[]
    coverage={}
    for k,indices in PART_IDS.items():
        block=ds[indices]
        ok=block.max(0)<=TOL
        if k=='output merge':
            ok &= same
        order=np.argsort(block.mean(0),kind='stable')
        domain=order[ok[order]]
        if domain.size:
            coverage[k]=dict(count=int(domain.size),closest=int(domain[0]))
        else:
            missing.append(k)
        domains[k]=domain
    out.update(covered=len(coverage),missing=missing)
    if detail:
        out['fragment_records']=coverage
    if missing:
        return dict(**out,status='partial')
    attempts=0
    def search(todo,assigned):
        nonlocal attempts
        if not todo:
            return assigned
        k=min(todo,key=lambda n:len(todo[n]))
        for j in todo[k]:
            attempts+=1
            if attempts>5000:
                raise TimeoutError
            remaining={}
            for b,d in todo.items():
                if b==k:
                    continue
                for stone in SHARED[k,b]:
                    if len(d) and stone:
                        a=bank[stone]
                        d=d[difference(SCHEMA[stone]['field'],a[d],a[j])<=TOL]
                if not len(d):
                    break
                remaining[b]=d
            else:
                result=search(remaining,dict(assigned,**{k:int(j)}))
                if result is not None:
                    return result
        return None
    try:
        donors=search(domains,{})
    except TimeoutError:
        return dict(**out,status='unresolved',attempts=attempts)
    if donors is None:
        return dict(**out,status='incompatible',attempts=attempts)
    assert len(set(donors.values()))>1
    return dict(**out,status='combination',donors=donors,attempts=attempts)


def stretches(close):
    adj=defaultdict(set)
    for child,parents in GRAPH.items():
        for p in parents:
            if close[INDEX[p]] and close[INDEX[child]]:
                adj[p].add(child)
                adj[child].add(p)
    remaining={k for k in NAMES if close[INDEX[k]]}
    components=[]
    while remaining:
        stack=[min(remaining)]
        comp=[]
        while stack:
            k=stack.pop()
            if k in remaining:
                remaining.remove(k)
                comp.append(k)
                stack.extend(adj[k])
        components.append(sorted(comp,key=INDEX.get))
    return sorted(components,key=len,reverse=True)


def walk(bank,q):
    return np.stack([difference(f,bank[k],q[k]) for k,f in zip(NAMES,FIELDS)])


def verify_values(snapshot):
    p,r=model.load(snapshot.parent,snapshot.name)
    replay={}
    model.forward(p,r['tokens'],replay)
    for k in set(FIELDS):
        np.testing.assert_array_equal(r[k],replay[k])


def run(seed):
    d=archive(seed)
    raw,ids=values(d/'inference.npz',GRAPH,SCHEMA)
    verify_values(d/'inference.npz')
    paths=sorted(d.glob('train_*.npz'))
    batches=[values(p,GRAPH,SCHEMA) for p in paths]
    bank={k:np.concatenate([r[k] for r,_ in batches]) for k in NAMES}
    hist_ids=np.concatenate([ii for _,ii in batches])
    assert len(hist_ids)==960 and not np.intersect1d(ids,hist_ids).size
    rng=np.random.default_rng(44000+seed)
    fake={k:v[np.argsort(rng.random((120,8)),axis=1).ravel()+np.repeat(np.arange(120)*8,8)] for k,v in bank.items()}
    sanity=walk(bank,{k:v[0] for k,v in bank.items()})
    assert classify(sanity,bank,bank['margin'][0,0]>=0,False)['literal_count']>=1
    rows=[]
    checked=set()
    for i,ex in enumerate(ids):
        q={k:v[i] for k,v in raw.items()}
        answer=bool(q['margin'][0]>=0)
        ds=walk(bank,q)
        scores=WEIGHTS@ds
        win=int(scores.argmin())
        rec=classify(ds,bank,answer,True)
        scrambled=walk(fake,q)
        control=classify(scrambled,fake,answer,False)
        close=ds[:,win]<=TOL
        stone_data={}
        for j,k in enumerate(NAMES):
            stone_data[k]=dict(query=q[k].tolist(),training=bank[k][win].tolist(),
                               distance=float(ds[j,win]),aligned=bool(close[j]))
        first=[k for j,k in enumerate(NAMES) if not close[j] and all(close[p] for p in PARENTS[j])]
        rejoin=[k for j,k in enumerate(NAMES) if close[j] and any(not close[p] for p in PARENTS[j])]
        used={win,*rec.get('donors',{}).values(),*(x['closest'] for x in rec.get('fragment_records',{}).values())}
        for j in used:
            if j//8 not in checked:
                verify_values(paths[j//8])
                checked.add(j//8)
        row=dict(seed=seed,i=i,example=int(ex),tokens=model.DATA[ex].tolist(),predicted=int(answer),
                 expected=int(model.LABEL[ex]),closest=win,training_tokens=model.DATA[hist_ids[win]].tolist(),
                 training_answer=int(bank['margin'][win,0]>=0),score=float(scores[win]),
                 control_score=float((WEIGHTS@scrambled).min()),record=rec,control=control,
                 aligned=int(close.sum()),breaks=first,rejoins=rejoin,components=stretches(close),stones=stone_data)
        rows.append(row)
    (OUT/f'seed_{seed}.json').write_text(json.dumps(rows,separators=(',',':')))
    return rows


def main():
    OUT.mkdir(exist_ok=True)
    rows=[]
    for seed in range(104,144):
        rows.extend(run(seed))
    summary=dict(cases=len(rows),seeds=len({r['seed'] for r in rows}),distinct_inputs=len({r['example'] for r in rows}),
                 statuses=Counter(r['record']['status'] for r in rows),control=Counter(r['control']['status'] for r in rows),
                 literal=sum(bool(r['record']['literal_count']) for r in rows),
                 genuine_closer=sum(r['score']<r['control_score'] for r in rows),
                 mean_closest=float(np.mean([r['score'] for r in rows])),
                 mean_control=float(np.mean([r['control_score'] for r in rows])),
                 missing=Counter(k for r in rows for k in r['record'].get('missing',[])))
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    from viewer import render
    render(rows)
    print(summary)


if __name__=='__main__':
    main()

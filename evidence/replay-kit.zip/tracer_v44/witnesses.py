"""Read assembled witnesses independently from disk, validate all seams and expose values."""
from itertools import combinations
from pathlib import Path

import numpy as np


def attach(rows):
    from journeys import PARTS, SCHEMA, TOL, archive
    for r in rows:
        rec=r['record']
        if rec['status'] not in ('whole','combination'):
            continue
        stones={}
        parts={}
        cache={}
        for part,j in rec['donors'].items():
            file=archive(r['seed'])/f'train_{j//8:03}.npz'
            if file not in cache:
                with np.load(file) as f:
                    cache[file]={k:f[k] for k in {n['field'] for n in SCHEMA.values()}|{'example_ids'}}
            snap=cache[file]
            obs={}
            for k in PARTS[part]:
                spec=SCHEMA[k]
                value=np.atleast_1d(snap[spec['field']][(j%8,*spec['index'])])
                query=np.array(r['stones'][k]['query'])
                if spec['field']!='tokens':
                    assert np.linalg.norm(value-query)<=TOL*max(1e-12,np.linalg.norm(value)+np.linalg.norm(query))+1e-12
                if k=='margin':
                    assert (value[0]>=0)==bool(r['predicted'])
                obs[k]=value.tolist()
                stones.setdefault(k,[]).append(value)
            parts[part]=dict(id=j,tokens=snap['tokens'][j%8].tolist(),values=obs)
        worst=0.
        for k,vals in stones.items():
            for a,b in combinations(vals,2):
                dist=np.linalg.norm(a-b)/max(1e-12,np.linalg.norm(a)+np.linalg.norm(b))
                worst=max(worst,float(dist))
                assert dist<=TOL+1e-12
        assert set(stones)==set(r['stones'])
        r['witnesses']=parts
        r['max_seam_distance']=worst

"""Lay the first held-out journey of seed 108 over each archived training journey."""
import json
from pathlib import Path
from graphlib import TopologicalSorter
from collections import defaultdict
import numpy as np

HERE = Path(__file__).resolve().parent
SNAPS = HERE.parent/'tracer_v38/results/seed_108/snapshots'
GRAPH = HERE.parent/'tracer_v37/results/graph.json'
TOL = 0.15


def ancestors(schema):
    seen = {}
    def visit(name):
        if name not in seen:
            seen[name] = [p for p in schema[name]['parents'] if p in schema]
            for p in seen[name]:
                visit(p)
    visit('margin')
    return {k:seen[k] for k in TopologicalSorter(seen).static_order()}


def values(snapshot, graph, schema):
    with np.load(snapshot) as f:
        arrays = {schema[k]['field']:None for k in graph}
        for field in arrays:
            arrays[field] = f[field]
        result = {}
        for k in graph:
            node = schema[k]
            a = arrays[node['field']][(slice(None), *node['index'])]
            result[k] = a.reshape(len(a), -1)
        return result, f['example_ids']


def difference(field, a, b):
    if field=='tokens':
        return (a[:,0]!=b[0]).astype(float)
    return np.linalg.norm(a-b,axis=1) / np.maximum(np.linalg.norm(a,axis=1)+np.linalg.norm(b),1e-12)


def main():
    schema = json.loads(GRAPH.read_text())
    graph = ancestors(schema)
    inf, test_ids = values(SNAPS/'inference.npz',graph,schema)
    q = {k:v[0] for k,v in inf.items()}
    candidates = []
    for file in sorted(SNAPS.glob('train_*.npz')):
        train,ids = values(file,graph,schema)
        assert not set(ids) & set(test_ids)
        by_field = defaultdict(list)
        cumulative = {}
        for k,parents in graph.items():
            local = difference(schema[k]['field'], train[k], q[k])
            cumulative[k] = (local + np.mean([cumulative[p] for p in parents],axis=0))/2 if parents else local
            # Compare the answer only after retrieval; its logit never selects a candidate.
            if k!='margin':
                by_field[schema[k]['field']].append(cumulative[k])
        score = np.mean([np.mean(v,axis=0) for v in by_field.values()],axis=0)
        candidates.extend(dict(file=file.name,row=i,example=int(ids[i]),distance=float(s)) for i,s in enumerate(score))
    assert len(candidates)==960
    candidates.sort(key=lambda c:(c['distance'], c['file'], c['row']))
    win = candidates[0]
    bank,_ = values(SNAPS/win['file'],graph,schema)
    stones = {}
    for k,parents in graph.items():
        t = bank[k][win['row']]
        d = float(difference(schema[k]['field'],t[None,:],q[k])[0])
        close = d<=TOL
        stones[k] = dict(inference=q[k].tolist(),training=t.tolist(),parents=parents,
                         parameters=[p for p in schema[k]['parents'] if p not in schema],
                         distance=d,close=close,unbroken=close and all(stones[p]['unbroken'] for p in parents))
    report = dict(seed=108,query_row=0,query_example=int(test_ids[0]),winner=win,
                  threshold=TOL,stones=stones)
    (HERE/'overlay.json').write_text(json.dumps(report,indent=2))
    (HERE/'ranking.json').write_text(json.dumps(candidates,indent=2))
    from display_overlay import render
    render(report)
    print(win)

if __name__=='__main__':
    main()

"""Render an overview and an expandable, value-bearing map of every answer ancestor."""
import json
from pathlib import Path
from html import escape
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
BG, INK, MUTED = '#f8f6ef','#172c39','#49606a'
GREEN, AMBER = '#00715c','#a4441d'
LIGHT, PEACH = '#e0f0e9','#fbe8da'


def font(size, bold=False):
    for name in (('Arial Bold.ttf' if bold else 'Arial.ttf'),('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')):
        try:
            return ImageFont.truetype(name,size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def overview(r):
    s = r['stones']
    im = Image.new('RGB',(1380,740),BG)
    d = ImageDraw.Draw(im)
    def text(x,y,content,size=22,color=INK,bold=False):
        d.text((x,y),content,font=font(size,bold),fill=color)
    def line(x1,y1,x2,y2):
        d.line((x1,y1,x2,y2),fill=MUTED,width=3)
    def box(x,y,w,h,title,detail,key):
        close = s[key]['close']
        col = GREEN if close else AMBER
        d.rounded_rectangle((x,y,x+w,y+h),12,fill=LIGHT if close else PEACH,outline=col,width=2)
        text(x+12,y+10,title,21,col,True)
        text(x+12,y+43,detail,18)
    text(40,25,'One inference journey over its closest training journey',38,INK,True)
    win=r['winner']
    step=int(win['file'][6:9])
    text(40,83,f"Seed {r['seed']}   /   held-out row 0   /   training step {step}, row {win['row']}   /   inference values shown first",21,MUTED)
    text(40,150,'The four messages entering the query',26,INK,True)
    for i,name in enumerate(('A','B','Selector','Query')):
        x=40+330*i
        t=s[f'tokens/{i}']
        box(x,198,300,78,f"{name}   {t['inference'][0]} / {t['training'][0]}",
            'Message aligns' if s[f'msg/3/{i}']['close'] else 'Message diverges',f'msg/3/{i}')
    text(40,315,'Follow the selector through its fork',26,INK,True)
    def vals(k):
        return ' / '.join(f'{s[k][a][0]:+.3f}' for a in ('inference','training'))
    line(225,452,295,404)
    line(225,452,295,502)
    line(510,404,565,431)
    line(510,502,565,456)
    line(765,445,820,445)
    line(1030,445,1080,445)
    box(40,414,185,78,'Selector','Token 10 / 11','tokens/2')
    box(295,365,215,78,'Routing weight',vals('w/3/2'),'w/3/2')
    box(295,465,215,78,'Value sent','Vectors diverge','value/2')
    box(565,405,200,80,'Message','Vectors diverge','msg/3/2')
    box(820,405,210,80,'Residual merge','Vectors align','y/3')
    cls = ['class '+str(int(s['margin'][a][0]>=0)) for a in ('inference','training')]
    box(1080,405,258,80,'Output margin',vals('margin'),'margin')
    text(40,571,'At the residual merge, all four messages and the query residual meet.',23)
    text(40,611,'Both runs choose '+cls[0]+'. The complete map expands the routing and all 12 neuron branches.',22)
    d.ellipse((41,685,57,701),fill=GREEN)
    text(69,678,'Aligned value',20,GREEN,True)
    d.ellipse((251,685,267,701),fill=AMBER)
    text(279,678,'Divergent value',20,AMBER,True)
    text(490,678,'Color describes the local comparison; the arrows summarize recorded dependencies.',19,MUTED)
    im.save(HERE/'journey.png')


def render(r):
    overview(r)
    s = r['stones']
    # Fixed operation columns, variable rows. Every data-parent edge is rendered.
    columns = ['tokens','e','x','q k v','score value','w','msg','y','pre','act','neuron','z','margin']
    pos = {}
    for col,fields in enumerate(columns):
        nodes = sorted((k for k in s if k.split('/')[0] in fields.split()),
                       key=lambda k: (k.split('/')[0],tuple(map(int,k.split('/')[1:]))))
        for i,k in enumerate(nodes):
            pos[k]=(75+col*150,55+(i+.5)*635/len(nodes))
    svg=['<svg viewBox="0 0 1960 740" aria-label="All stones feeding the answer">']
    for k,v in s.items():
        x,y=pos[k]
        for p in v['parents']:
            px,py=pos[p]
            svg.append(f'<path d="M {px+45} {py} C {px+95} {py}, {x-95} {y}, {x-45} {y}" fill="none" stroke="#a9b6b7" stroke-width="1.5"/>')
    for k,v in s.items():
        x,y=pos[k]
        color=GREEN if v['close'] else AMBER
        fill=LIGHT if v['close'] else PEACH
        svg.append(f'<a href="#stone-{k}"><rect x="{x-46}" y="{y-15}" width="92" height="30" rx="12" fill="{fill}" stroke="{color}"/><text x="{x}" y="{y+5}" text-anchor="middle" fill="{color}">{k}</text></a>')
    svg.append('</svg>')
    sections=[]
    for k,v in s.items():
        def nums(key):
            return '  '.join(f'{x:.5g}' for x in v[key])
        parents=' · '.join(f'<a href="#stone-{p}">{p}</a>' for p in v['parents']) or 'input'
        children=' · '.join(f'<a href="#stone-{c}">{c}</a>' for c,w in s.items() if k in w['parents']) or 'answer'
        sections.append(f"""<tr id="stone-{k}"><th>{k}</th><td>{'Aligned' if v['close'] else 'Divergent'}<br>{v['distance']:.3f}</td>
        <td>{nums('inference')}<hr>{nums('training')}</td><td>{parents}</td><td>{children}</td>
        <td>{'All aligned' if v['unbroken'] else 'Contains divergence'}</td></tr>""")
    html="""<meta charset="utf-8"><title>Training and inference stone overlay</title><style>
    body{background:#f8f6ef;color:#172c39;font:17px system-ui;margin:3vw}img{width:100%;max-width:1380px}
    .map{overflow:auto}svg{min-width:1400px;width:100%;font:14px monospace}th,td{text-align:left;padding:10px;border-bottom:1px solid #ccd4cd}
    td{max-width:33em}tr:target{background:#fff2b3}a{color:#175764}hr{border:0;border-top:1px solid #d2d9d6}table{border-collapse:collapse}</style>
    <img src="journey.png" alt="Overview of the selector branch and its merge"><h2>Every stone that feeds the answer</h2>
    <p>Follow the graph from left to right. Select a stone to see its two recorded values and follow its parents or children.
    Green means locally aligned; orange means locally divergent. Shared geometry comes from the common architecture.</p><div class="map">"""
    html+=''.join(svg)+'</div><h2>Recorded values</h2><table><thead><tr><th>Stone</th><th>Comparison<br>distance</th><th>Inference above · training below</th><th>Parents</th><th>Children</th><th>Ancestry</th></tr></thead><tbody>'
    (HERE/'journey.html').write_text(html+''.join(sections)+'</tbody></table>')

from pathlib import Path
import json,sys
import numpy as np
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tracer_v46'))
import influence
expected=json.loads((root/'tracer_v46/results/seed_111.json').read_text())
influence.OUT=root/'replayed'
influence.OUT.mkdir(exist_ok=True)
rows,err=influence.run(111)
for a,b in zip(rows,expected,strict=True):
    for k in ('factual','omitted','branch_stopped','patched'):
        np.testing.assert_allclose(a[k],b[k],atol=1e-10,rtol=1e-10)
r=rows[9]
print('Verified 16 cases. Highlighted case:',r['factual'],r['branch_stopped'][r['source']])

import json
import sys
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'tracer_v44'))
import journeys as j
m=j.model
OUT=HERE/'results'
FIELDS=sorted(set(j.FIELDS))


def dump(path,data):
    path.write_text(json.dumps(data,indent=2))


def bank_values(records):
    return {k:records[spec['field']][(slice(None),*spec['index'])].reshape(len(records['margin']),-1)
            for k in j.NAMES for spec in [j.SCHEMA[k]]}


def run_model(d,train,probe,test,batches,initial):
    d.mkdir(parents=True,exist_ok=True)
    p={k:v.copy() for k,v in initial.items()}
    twin={k:v.copy() for k,v in initial.items()}
    states=[{k:(np.zeros_like(v),np.zeros_like(v)) for k,v in p.items()} for _ in range(2)]
    archives={'training':[],'probe':[]}
    parameters={k:[] for k in p}
    for step,idx in enumerate(batches):
        train_ids=train[idx]
        t,c={},{}
        margin,cache=m.forward(p,m.DATA[train_ids],t)
        m.forward(p,m.DATA[probe[idx]],c)
        plain,ct=m.forward(twin,m.DATA[train_ids])
        assert np.array_equal(margin,plain)
        g=m.backward(p,cache,margin,m.LABEL[train_ids])
        gt=m.backward(twin,ct,plain,m.LABEL[train_ids])
        assert all(np.array_equal(g[k],gt[k]) for k in g)
        for name,records in [('training',t),('probe',c)]:
            archives[name].append(records)
        for k in p:
            parameters[k].append(p[k].copy())
        m.update(p,g,states[0],step+1)
        m.update(twin,gt,states[1],step+1)
        assert all(np.array_equal(p[k],twin[k]) for k in p)
    q={}
    logits,_=m.forward(p,m.DATA[test],q)
    assert np.array_equal(logits,m.forward(twin,m.DATA[test])[0])
    np.savez_compressed(d/'weights.npz',**{k:np.stack(v+[p[k]]) for k,v in parameters.items()})
    np.savez_compressed(d/'inference.npz',example_ids=test,**q)
    qs=bank_values(q)
    rows=[dict(example=int(ex),prediction=int(logits[i]>=0),expected=int(m.LABEL[ex])) for i,ex in enumerate(test)]
    for name,chunks in archives.items():
        ids=(train if name=='training' else probe)[batches].ravel()
        rec={k:np.concatenate([c[k] for c in chunks]) for k in FIELDS}
        np.testing.assert_array_equal(rec['tokens'],m.DATA[ids])
        np.savez_compressed(d/f'{name}.npz',example_ids=ids,**rec)
        bank=bank_values(rec)
        ds=j.walk(bank,{k:a[0] for k,a in bank.items()})
        assert j.classify(ds,bank,bank['margin'][0,0]>=0,False)['literal_count']>=1
        for i,row in enumerate(rows):
            ds=j.walk(bank,{k:a[i] for k,a in qs.items()})
            scores=j.WEIGHTS@ds
            row[name]=dict(j.classify(ds,bank,logits[i]>=0,True),closest=int(scores.argmin()),
                           distance=float(scores.min()))
    dump(d/'comparisons.json',rows)
    return rows


def complete(result):
    return result['status'] in ('whole','combination')


def main():
    OUT.mkdir(exist_ok=True)
    summaries=[]
    for seed in range(144,156):
        rng=np.random.default_rng(seed)
        classes=[rng.permutation(np.flatnonzero(m.LABEL==i)) for i in (0,1)]
        a,b,test=[rng.permutation(np.concatenate([c[lower:upper] for c in classes]))
                  for lower,upper in [(0,12),(12,24),(24,32)]]
        initial=m.init(rng)
        batches=np.array([rng.choice(24,m.BATCH,replace=False) for _ in range(m.STEPS)])
        assert len(set(a)|set(b)|set(test))==64 and len(np.unique(batches))==24
        rows=[]
        for name,train,probe in [('A',a,b),('B',b,a)]:
            rows.extend(run_model(OUT/f'pair_{seed}'/name,train,probe,test,batches,initial))
        counts={'both':0,'training_only':0,'probe_only':0,'neither':0}
        for row in rows:
            x,y=complete(row['training']),complete(row['probe'])
            counts[['neither','probe_only','training_only','both'][2*x+y]]+=1
        summaries.append(dict(seed=seed,**counts,
            unresolved=sum(r[n]['status']=='unresolved' for n in ('training','probe') for r in rows),
            single={n:sum(r[n]['status']=='whole' for r in rows) for n in ('training','probe')},
            mean_distance={n:float(np.mean([r[n]['distance'] for r in rows])) for n in ('training','probe')}))
    totals={k:sum(s[k] for s in summaries) for k in ('both','training_only','probe_only','neither','unresolved')}
    diff=np.array([s['training_only']-s['probe_only'] for s in summaries])/32
    boot=np.random.default_rng(451).choice(diff,size=(20000,len(diff)),replace=True).mean(axis=1)
    report=dict(totals=totals,paired_rate_difference=float(diff.mean()),
                bootstrap_interval=np.quantile(boot,[.025,.975]).tolist(),pairs=summaries)
    dump(OUT/'summary.json',report)
    print(totals,report['bootstrap_interval'],diff)


if __name__=='__main__':
    main()

"""Single-pass occurrence tracing. Run with Python 3 and NumPy."""
import itertools
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
SEEDS = (104, 105, 106, 107)
STEPS, BATCH, D, H = 120, 8, 8, 12
DATA = np.array([[a, b+4, c+8, 12] for a,b,c in itertools.product(range(4), repeat=3)])
LABEL = np.where(DATA[:,2] % 2 == 0, DATA[:,0] % 2, DATA[:,1] % 2)
SOURCES = (0, 1, 2)


def init(rng):
    shapes = dict(emb=(13,D), pos=(4,D), Q=(D,D), K=(D,D), V=(D,D),
                  O=(D,D), U=(D,H), b=(H,), T=(H,D), c=(D,), head=(D,), bias=(1,))
    return {k: (rng.normal(size=s)*(.5 if k in ('emb','pos') else 1/np.sqrt(D))
                if k not in ('b','c','bias') else np.zeros(s)) for k,s in shapes.items()}


def forward(p, tokens, recorder=None, cut=None):
    e = p['emb'][tokens]
    x = e + p['pos']
    q,k,v = (x @ p[name] for name in ('Q','K','V'))
    score = q @ k.transpose(0,2,1) / np.sqrt(D)
    exp = np.exp(score-score.max(-1,keepdims=True))
    w = exp/exp.sum(-1,keepdims=True)
    value = v @ p['O']
    msg = w[...,None] * value[:,None,:,:]
    if cut is not None:  # validation only, one query-bound message per occurrence
        msg[np.arange(len(tokens)),3,cut] = 0
    y = x + msg.sum(2)
    pre = y @ p['U'] + p['b']
    act = np.tanh(pre)
    neuron = act[...,None]*p['T']
    z = y + neuron.sum(2) + p['c']
    margin = z[:,3] @ p['head'] + p['bias']
    if recorder is not None:
        recorder.update(tokens=tokens,e=e,x=x,q=q,k=k,v=v,score=score,w=w,value=value,
                        msg=msg,y=y,pre=pre,act=act,neuron=neuron,z=z,margin=margin)
    return margin, (tokens,x,q,k,v,w,value,y,act,z)


def backward(p, cache, margin, target):
    tokens,x,q,k,v,w,value,y,act,z = cache
    dm = (1/(1+np.exp(-margin))-target)/len(target)
    dz = np.zeros_like(z)
    dz[:,3] = dm[:,None]*p['head']
    dp = (dz @ p['T'].T)*(1-act**2)
    dy = dz + dp @ p['U'].T
    dvout = w.transpose(0,2,1) @ dy
    dw = dy @ value.transpose(0,2,1)
    ds = w*(dw-(dw*w).sum(-1,keepdims=True))/np.sqrt(D)
    dq,dk,dv = ds @ k, ds.transpose(0,2,1) @ q, dvout @ p['O'].T
    dx = dy + dq @ p['Q'].T + dk @ p['K'].T + dv @ p['V'].T
    de = np.zeros_like(p['emb'])
    np.add.at(de,tokens,dx)
    def outer(a,b):
        return np.einsum('bti,btj->ij',a,b)
    return dict(emb=de,pos=dx.sum(0),Q=outer(x,dq),K=outer(x,dk),V=outer(x,dv),
                O=outer(v,dvout),U=outer(y,dp),b=dp.sum((0,1)),T=outer(act,dz),
                c=dz.sum((0,1)),head=dm @ z[:,3],bias=np.array([dm.sum()]))


def loss(m,t):
    return np.mean(np.logaddexp(0,m)-t*m)


def update(p,g,state,step):
    for k in p:
        a,b = state[k]
        a *= .9
        a += .1*g[k]
        b *= .999
        b += .001*g[k]**2
        p[k] -= .015*(a/(1-.9**step))/(np.sqrt(b/(1-.999**step))+1e-8)


def gradient_check(p):
    rng = np.random.default_rng(8)
    ids = [0,19,26,63]
    x,t = DATA[ids],LABEL[ids]
    m,cache = forward(p,x)
    g = backward(p,cache,m,t)
    direction = {k:rng.normal(size=v.shape) for k,v in p.items()}
    def probe(h):
        pars = {k:v+h*direction[k] for k,v in p.items()}
        return loss(forward(pars,x)[0],t)
    diff = abs((probe(1e-5)-probe(-1e-5))/2e-5-sum((g[k]*d).sum() for k,d in direction.items()))
    assert diff < 1e-7
    return float(diff)


def features(r,p,src):
    # Input baseline uses only token IDs. Activation baseline sees receiver and source.
    inp = r['tokens'][:,:3]
    local = np.concatenate((r['x'][:,src],r['y'][:,3],r['act'][:,3]),axis=1)
    # Roles kept separate: source routing weight, projected message, its signed
    # input to each nonlinear unit, and the observed operating point at that join.
    msg = r['msg'][:,3,src]
    route = [r['w'][:,3,src,None],msg,msg @ p['U'],r['pre'][:,3]]
    return inp, local, route


def distance(bank,row):
    return ((bank-row)**2).sum(-1)/(1e-9+(bank**2).sum(-1)+(row**2).sum())


def save(directory,name,p,r,ids):
    np.savez_compressed(directory/name,**r,example_ids=ids,**{'param_'+k:v for k,v in p.items()})


def load(directory,name):
    with np.load(directory/name) as f:
        return ({k[6:]:f[k] for k in f if k.startswith('param_')},
                {k:f[k] for k in f if not k.startswith('param_')})


def evaluate(directory,seed):
    rng = np.random.default_rng(seed+50000)
    pf,query = load(directory,'inference.npz')
    bank = [load(directory,f'train_{i:03}.npz') for i in range(STEPS)]
    targets = np.concatenate([r['margin'] for _,r in bank])
    perm = rng.permutation(len(targets))  # shared random tie break for all matchers
    requests = []
    for src in SOURCES:
        rows = [features(r,p,src) for p,r in bank]
        ib,ab = [np.concatenate([a[j] for a in rows]) for j in (0,1)]
        rb = [np.concatenate([a[2][j] for a in rows]) for j in range(4)]
        iq,aq,rq = features(query,pf,src)
        for i,tok in enumerate(iq):
            overlap = (ib==tok).sum(-1)
            same = (targets>=0)==(query['margin'][i]>=0)
            eligible = perm[same[perm]]
            eligible = eligible[overlap[eligible]==overlap[eligible].max()]
            def best(d):
                return int(eligible[np.argmin(d[eligible])])
            ids = dict(input=int(eligible[0]),activation=best(distance(ab,aq[i])),
                       message_only=best(distance(rb[1],rq[1][i])),
                       trace=best(sum(distance(b,q[i]) for b,q in zip(rb,rq))))
            requests.append(dict(query=i,source=src,example=int(query['example_ids'][i]),
                                 candidates=len(eligible),training_occurrences=ids))
    (directory/'matches.json').write_text(json.dumps(requests,indent=2))
    # Matches locked on disk before interventions. Re-execute historical weights.
    def effects(p,r,src):
        raw,_ = forward(p,r['tokens'])
        assert np.array_equal(raw,r['margin'])
        cut,cache = forward(p,r['tokens'],cut=src)
        pre_cut = cache[7][:,3] @ p['U']+p['b']
        receiver = pre_cut-r['pre'][:,3]
        assert np.max(abs(receiver+r['msg'][:,3,src] @ p['U'])) < 1e-10
        return cut-raw,receiver
    history = {}
    observed = {}
    for src in SOURCES:
        hist = [effects(p,r,src) for p,r in bank]
        history[src] = tuple(np.concatenate(v) for v in zip(*hist))
        observed[src] = effects(pf,query,src)
    for item in requests:
        i,s = item['query'],item['source']
        delta,receiver = observed[s]
        item['actual_margin_change'] = float(delta[i])
        item['predicted_margin_change'] = {}
        item['receiver_rmse'] = {}
        for method,h in item['training_occurrences'].items():
            pred,rec = history[s]
            item['predicted_margin_change'][method] = float(pred[h])
            item['receiver_rmse'][method] = float(np.mean((rec[h]-receiver[i])**2)**.5)
        # Alternative source at same retrieved occurrence, closest in message norm.
        h = item['training_occurrences']['trace']
        _,r = bank[h//BATCH]
        mag = np.linalg.norm(r['msg'][h%BATCH,3],axis=-1)
        other = min((j for j in SOURCES if j!=s),key=lambda j:abs(mag[j]-mag[s]))
        item['predicted_margin_change']['other_edge'] = float(history[other][0][h])
    (directory/'validation.json').write_text(json.dumps(requests,indent=2))
    return {method:dict(mae=float(np.mean([abs(v['predicted_margin_change'][method]-v['actual_margin_change']) for v in requests])),
                        sign_agreement=float(np.mean([np.sign(v['predicted_margin_change'][method])==np.sign(v['actual_margin_change']) for v in requests])))
            for method in requests[0]['predicted_margin_change']}


def run(seed):
    d = OUT/f'seed_{seed}'
    d.mkdir(parents=True,exist_ok=True)
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(DATA))
    train,test = order[:48],order[48:]
    p = init(rng)
    twin = {k:v.copy() for k,v in p.items()}
    states = [{k:(np.zeros_like(v),np.zeros_like(v)) for k,v in p.items()} for _ in range(2)]
    err = gradient_check(p)
    for step in range(STEPS):
        ids = rng.choice(train,BATCH,replace=False)
        r = {}
        m,c = forward(p,DATA[ids],r)
        mt,ct = forward(twin,DATA[ids])
        assert np.array_equal(m,mt)
        g,gt = backward(p,c,m,LABEL[ids]),backward(twin,ct,mt,LABEL[ids])
        assert all(np.array_equal(g[k],gt[k]) for k in p)
        save(d,f'train_{step:03}.npz',p,r,ids)
        update(p,g,states[0],step+1)
        update(twin,gt,states[1],step+1)
        assert all(np.array_equal(p[k],twin[k]) for k in p)
    r = {}
    m,_ = forward(p,DATA[test],r)
    assert np.array_equal(m,forward(twin,DATA[test])[0])
    save(d,'inference.npz',p,r,test)
    (d/'answers.json').write_text(json.dumps([
        dict(occurrence=i,tokens=DATA[idx].tolist(),expected=int(LABEL[idx]),
             predicted=int(m[i]>=0),margin=float(m[i])) for i,idx in enumerate(test)],indent=2))
    return dict(seed=seed,correct=int(((m>=0)==LABEL[test]).sum()),heldout=len(test),
                gradient_check_error=err,metrics=evaluate(d,seed))


if __name__=='__main__':
    start = time.perf_counter()
    results = []
    for seed in SEEDS:
        result = run(seed)
        results.append(result)
        print(json.dumps(result),flush=True)
    report = dict(results=results,seconds=time.perf_counter()-start,numpy=np.__version__,
                  python=sys.version,platform=platform.platform(),trace_bytes=sum(p.stat().st_size for p in OUT.rglob('*.npz')))
    from inspect_trace import write_graph, write_example
    write_graph(OUT)
    write_example(OUT)
    (OUT/'summary.json').write_text(json.dumps(report,indent=2))

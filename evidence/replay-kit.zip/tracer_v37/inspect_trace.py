"""One shared dependency schema indexes exact event values in every NPZ occurrence."""
import json
from pathlib import Path

import numpy as np


def write_graph(out):
    nodes = {}
    def put(field, idx, parents):
        key = '/'.join([field,*map(str,idx)])
        nodes[key] = dict(field=field,index=idx,parents=parents)
    for i in range(4):
        put('tokens',[i],[])
        put('e',[i],[f'tokens/{i}','param_emb'])
        put('x',[i],[f'e/{i}',f'param_pos/{i}'])
        for fld in ('q','k','v'):
            put(fld,[i],[f'x/{i}','param_'+fld.upper()])
        put('value',[i],[f'v/{i}','param_O'])
    for i in range(4):
        for j in range(4):
            put('score',[i,j],[f'q/{i}',f'k/{j}'])
            put('w',[i,j],[f'score/{i}/{a}' for a in range(4)])
            put('msg',[i,j],[f'w/{i}/{j}',f'value/{j}'])
        put('y',[i],[f'x/{i}',*[f'msg/{i}/{a}' for a in range(4)]])
        for h in range(12):
            put('pre',[i,h],[f'y/{i}','param_U',f'param_b/{h}'])
            put('act',[i,h],[f'pre/{i}/{h}'])
            put('neuron',[i,h],[f'act/{i}/{h}',f'param_T/{h}'])
        put('z',[i],[f'y/{i}',*[f'neuron/{i}/{h}' for h in range(12)],'param_c'])
    put('margin',[],['z/3','param_head','param_bias'])
    (out/'graph.json').write_text(json.dumps(nodes,indent=2))


def write_example(out):
    directory = out/'seed_104'
    item = json.loads((directory/'validation.json').read_text())[0]
    h = item['training_occurrences']['trace']
    panels = []
    for name,file,idx in [('Inference','inference.npz',0),
                          ('Retrieved training occurrence',f'train_{h//8:03}.npz',h%8)]:
        with np.load(directory/file) as d:
            w = d['w'][idx,3,0]
            n = np.linalg.norm(d['msg'][idx,3,0])
            p = d['pre'][idx,3,0]
            panels.append(f'<section><h2>{name}</h2><p>{file}, row {idx}</p><pre>tokens {d["tokens"][idx].tolist()}\n\nquery 3 + keys 0–3\n        ↓\nrow softmax → weight {w:.4f}\n                  × projected value from token 0\n                  ↓\n       message norm {n:.4f}\n                  ↓\nquery residual + all four messages\n         ├─→ unit 0 preactivation {p:.4f}\n         │   → tanh → neuron message\n         │   (+ 11 other neurons)\n         └─→ residual skip\n                  ↓\n           sum + readout\n                  ↓\n           margin {d["margin"][idx]:.4f}</pre></section>')
    (out/'example.html').write_text('<meta charset="utf-8"><title>Recorded pair</title><style>body{font:16px system-ui;margin:3vw}main{display:flex;gap:4vw;flex-wrap:wrap}pre{line-height:1.5}</style><h1>Seed 104 · first held-out input · source 0</h1><main>'+''.join(panels)+'</main><p>Zeroing the source-0 message changed the historical margin by %.4f and the inference margin by %.4f.</p>'%(item['predicted_margin_change']['trace'],item['actual_margin_change']))


if __name__=='__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Inspect an event and its immediate parents.')
    parser.add_argument('snapshot',type=Path)
    parser.add_argument('row',type=int)
    parser.add_argument('event',help='e.g. msg/3/0')
    args = parser.parse_args()
    graph = json.loads((args.snapshot.parent.parent/'graph.json').read_text())
    with np.load(args.snapshot) as data:
        node = graph[args.event]
        print(json.dumps(dict(event=args.event,parents=node['parents'],
                              value=data[node['field']][(args.row,*node['index'])].tolist()),indent=2))
